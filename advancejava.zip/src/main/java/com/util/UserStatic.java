package com.util;

public class UserStatic {
	public static int user_counter=0;  
}
