package com.controller;

import javax.servlet.http.HttpServlet;

public class Basic extends HttpServlet  {

}
